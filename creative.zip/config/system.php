<?php
return [
	'default_role' => [
		'admin' => 'Super Admin',
	],
];