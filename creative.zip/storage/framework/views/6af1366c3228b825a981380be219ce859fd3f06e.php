<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="badge-header">
            <div class="row">
                <div class="col-md-6">
                    <button class="title btn btn-outline btn-wd mt-2">
                    <i class="fa fa-check"></i>
                    
                    <?php echo e($id); ?>

                    </button>
                </div>
                <div class="col-md-6" style="text-align: right;">
                    <a href="<?php echo e(route('admin.language')); ?>" class=" btn-icon btn btn-outline btn-round btn-wd mt-2">
                        <span class="btn-label">
                            <i class="glyphicon fa fa-th-list"></i>
                        </span><?php echo e(_lang('Language List')); ?>

                    </a>
                </div>
            </div>
        </div>
        <div class="card stacked-form">
            <div class="card-body ">
                <?php echo Form::open(['route' => ['admin.language.update',$id], 'id'=>'content_form','files' => true, 'method' => 'POST']); ?>

                <?php echo method_field('patch'); ?>
                <div class="row">
                    <?php $__currentLoopData = $language; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6">
                        <?php echo e(Form::label('language_name', ucwords($key) , ['class' => 'col-form-label required'])); ?>

                        <input type="text" class="form-control" name="language[<?php echo e(str_replace(' ','_',$key)); ?>]" value="<?php echo e($lang); ?>" required>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="row">
                    <div class="col-md-6 mx-auto text-center">
                        
                        <?php echo e(Form::submit(_lang('Translate Language'), ['class' => 'btn btn-outline btn-success btn-round btn-wd w-100 ', 'id' => 'submit'])); ?>

                        <button type="button" class="btn btn-link" id="submiting" style="display: none;" disabled=""><?php echo e(_lang('Submiting')); ?> <img src="<?php echo e(asset('loading.gif')); ?>" width="50"></button>
                    </div>
                </div>
                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', ['title' => __('Language'), 'modal' => false], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\creative\resources\views/admin/language/edit.blade.php ENDPATH**/ ?>