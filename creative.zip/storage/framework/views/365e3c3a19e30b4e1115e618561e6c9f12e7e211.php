<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">

		 <!-- CSRF Token -->
		<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

		<title>Install</title>

		<!-- Google font -->
		<link href="https://fonts.googleapis.com/css?family=Lato:700%7CMontserrat:400,600" rel="stylesheet">

		<!-- Bootstrap -->
		<link type="text/css" rel="stylesheet" href="<?php echo e(asset('install/css/bootstrap.min.css')); ?>"/>

		<!-- Custom stlylesheet -->
		<link type="text/css" rel="stylesheet" href="<?php echo e(asset('install/css/style.css')); ?>"/>

    </head>
	<body>

		<div class="container">
		    <div class="install-container col-md-12">
				<?php echo $__env->yieldContent('content'); ?>
			</div>			
		</div>

		<!-- jQuery Plugins -->
		<script type="text/javascript" src="<?php echo e(asset('install/js/jquery.min.js')); ?>"></script>
		<script type="text/javascript" src="<?php echo e(asset('install/js/bootstrap.min.js')); ?>"></script>
		<?php echo $__env->yieldContent('js-script'); ?>		
	</body>
</html><?php /**PATH D:\creative\resources\views/install/layout.blade.php ENDPATH**/ ?>