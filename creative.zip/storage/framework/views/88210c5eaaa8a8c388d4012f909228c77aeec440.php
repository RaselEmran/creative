<?php $__env->startSection('content'); ?>
<div class="container ">
    <div class="row">
        <div class="col-md-6 pb-3  pt-5  px-5 mx-auto text-center  text-white mt-0 mt-sm-5 bg-color">

            <?php if(setting('logo')): ?>
            <img src="<?php echo e(asset('storage/logo/'.setting('logo'))); ?>" alt="Logo"
                style="width:150px; height:150px; border-radius:50%;">
            <?php else: ?>
            <div class="border rounded-circle d-inline-block">
                <p class="display-2 mt-4 mr-5"> <i class="fa fa-user"></i> </p>
            </div>
            <?php endif; ?>
            <div class="mt-3 mt-sm-5 mx-0 mx-sm-2">
                <form action="<?php echo e(route('login')); ?>" method="post" id="login">
                    <div class="form-group row no-gutters">
                        <label for="email" class="col-2 col-form-label"> <i class="fa fa-address-card" aria-hidden="true"></i> </label>
                        <div class="col-10">
                            <input type="text" class="form-control" id="email" name="email" placeholder="Email" autofocus>
                        </div>
                    </div>
                    <div class="form-group row no-gutters">
                        <label for="password" class="col-2 col-form-label"> <i class="fa fa-unlock-alt" aria-hidden="true"></i> </label>
                        <div class="col-10">
                            <input type="password" class="form-control" name="password" id="password"  autocomplete="password" placeholder="Password">
                        </div>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary btn-block"
                            id="submit"><?php echo e(_lang('Sign in')); ?></button>
                    </div>
                     <div class="text-center">
                    <?php if(Route::has('password.request')): ?>
                    <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                        <?php echo e(__('Forgot Your Password?')); ?>

                    </a>
                    <?php endif; ?>
                </div>
                </form>
            </div>
            <br>
            <br>
         
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('js/login.js')); ?>"></script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\creative\resources\views/auth/login.blade.php ENDPATH**/ ?>