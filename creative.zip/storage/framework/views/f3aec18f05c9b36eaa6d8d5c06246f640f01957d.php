<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="nav-container" style=" border: 1px dotted">
        <ul class="nav nav-icons nav-justified" role="tablist">
            <li class="nav-item show active">
                <a class="nav-link" id="description-tab" href="#description-logo" role="tab" data-toggle="tab">
                    <i class="nc-icon nc-bank"></i>
                    <br> <?php echo e(_lang('Basic Setting')); ?>

                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="location-tab" href="#map-logo" role="tab" data-toggle="tab">
                    <i class="nc-icon nc-camera-20"></i>
                    <br> <?php echo e(_lang('Logo & Favicon')); ?>

                </a>
            </li>

        </ul>
    </div>
    <?php echo Form::open(['route' => 'admin.setting', 'class' => 'ajax_form','files' => true, 'method' => 'POST']); ?>

    <div class="tab-content">
        <div class="tab-pane fade show active" id="description-logo" aria-labelledby="info-tab">
            <div class="card">
                <div class="card-body">
                     <div class="row">
                <div class="col-md-6">
                  <?php echo e(Form::label('company_name', _lang('Company Name') , ['class' => 'col-form-label '])); ?>

                  <?php echo e(Form::text('company_name', setting('company_name'), ['class' => 'form-control', 'placeholder' => _lang('Company Name')])); ?>

                </div>
                <div class="col-md-6">
                  <?php echo e(Form::label('site_title', _lang('Title') , ['class' => 'col-form-label '])); ?>

                  <?php echo e(Form::text('site_title', setting('site_title'), ['class' => 'form-control', 'placeholder' => _lang('Title')])); ?>

                </div>
                <div class="col-md-6">
                  <?php echo e(Form::label('email', _lang('Email') , ['class' => 'col-form-label '])); ?>

                  <?php echo e(Form::text('email', setting('email'), ['class' => 'form-control', 'placeholder' => _lang('Email')])); ?>

                </div>
                <div class="col-md-6">
                  <?php echo e(Form::label(_lang('phone'), _lang('Phone') , ['class' => 'col-form-label '])); ?>

                  <?php echo e(Form::text('phone',setting('phone'), ['class' => 'form-control', 'placeholder' => _lang('Phone')])); ?>

                </div>
                <div class="col-md-6">
                  <?php echo e(Form::label('alt_phone', _lang('Alternative Phone') , ['class' => 'col-form-label '])); ?>

                  <?php echo e(Form::text('alt_phone', setting('alt_phone'), ['class' => 'form-control', 'placeholder' => _lang('Alternative Phone')])); ?>

                </div>
                <div class="col-md-6">
                  <?php echo e(Form::label('start_date', _lang('Starting Date') , ['class' => 'col-form-label '])); ?>

                  <?php echo e(Form::text('start_date', setting('start_date'), ['class' => 'form-control datepicker', 'placeholder' => _lang('Starting Date')])); ?>

                </div>
                <div class="col-md-6">
                  <?php echo e(Form::label('timezone', _lang('timezone') , ['class' => 'col-form-label '])); ?>

                  <select name="timezone" class="form-control select">
                    <?php $__currentLoopData = tz_list(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $time): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option  value="<?php echo e($time['zone']); ?>"><?php echo e($time['diff_from_GMT'] . ' - ' . $time['zone']); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
                <div class="col-md-6">
                  <?php echo e(Form::label('language', _lang('language') , ['class' => 'col-form-label '])); ?>

                  <select name="language" class="form-control select">
                    <?php echo load_language( setting('language') ); ?>

                  </select>
                </div>
                <div class="col-md-6">
                  <?php echo e(Form::label('land_mark', _lang('Land Mark') , ['class' => 'col-form-label'])); ?>

                  <?php echo e(Form::text('land_mark', setting('land_mark'), ['class' => 'form-control', 'placeholder' => _lang('Land Mark')])); ?>

                </div>
                <div class="col-md-6">
                  <?php echo e(Form::label('account', _lang('Account Module') , ['class' => 'col-form-label '])); ?>

                  <select name="account" class="form-control select" style="width: 100%">
                    <option <?php echo e(setting('account')=='Show'?'selected':''); ?> value="Show">Show</option>
                    <option <?php echo e(setting('account')=='Hide'?'selected':''); ?> value="Hide">Hide</option>
                  </select>
                </div>
                   <div class="col-md-6">
                  <?php echo e(Form::label('employee', _lang('Employee Module') , ['class' => 'col-form-label '])); ?>

                  <select name="employee" class="form-control select" style="width: 100%">
                    <option <?php echo e(setting('employee')=='Show'?'selected':''); ?> value="Show">Show</option>
                    <option <?php echo e(setting('employee')=='Hide'?'selected':''); ?> value="Hide">Hide</option>
                  </select>
                </div>
                   <div class="col-md-6">
                  <?php echo e(Form::label('permission', _lang('Permission Module') , ['class' => 'col-form-label '])); ?>

                  <select name="permission" class="form-control select" style="width: 100%">
                    <option <?php echo e(setting('permission')=='Show'?'selected':''); ?> value="Show">Show</option>
                    <option <?php echo e(setting('permission')=='Hide'?'selected':''); ?> value="Hide">Hide</option>
                  </select>
                </div>
                <div class="col-md-12">
                  <?php echo e(Form::label('address', _lang('Address') , ['class' => 'col-form-label'])); ?>

                  <?php echo e(Form::textarea('address', setting('address'), ['class' => 'form-control','id'=>'editor1', 'rows'=>3])); ?>

                </div>
              </div>
            </div>
            </div>
        </div>
        <div class="tab-pane fade" id="map-logo" aria-labelledby="info-tab">
            <div class="card">
                <div class="card-body">
                <div class="row">
                <div class="col-md-12">
                  <?php echo e(Form::label('logo', _lang('logo') , ['class' => 'col-form-label'])); ?>

                  <input type="file" name="logo" id="logo" class="dropify" data-default-file="<?php echo e(setting('logo')?asset('storage/logo/'.setting('logo')):''); ?>" />
                  <?php if(setting('logo')): ?>
                  <input type="hidden" name="oldLogo" value="<?php echo e(setting('logo')); ?>">
                  <?php endif; ?>
                </div>
                <div class="col-md-12">
                    <h3 style="text-align:center;">Settting Your Logo And Favicon Here</h3>
                </div>
                <div class="col-md-12">
                  <?php echo e(Form::label('favicon', _lang('favicon') , ['class' => 'col-form-label'])); ?>

                  <input type="file" name="favicon" id="favicon" class="dropify" data-default-file="<?php echo e(setting('favicon')?asset('storage/logo/'.setting('favicon')):''); ?>" />
                  <?php if(setting('favicon')): ?>
                  <input type="hidden" name="oldfavicon" value="<?php echo e(setting('favicon')); ?>">
                  <?php endif; ?>
                </div>
              </div>
                </div>
            </div>
        </div>
    </div>
  <div class="row">
  <div class="col-md-6 mx-auto text-center">
    
    <?php echo e(Form::submit(_lang('Create'), ['class' => 'btn btn-outline btn-success btn-round btn-wd w-100 ', 'id' => 'submit'])); ?>

    <button type="button" class="btn btn-link" id="submiting" style="display: none;" disabled=""><?php echo e(_lang('Submiting')); ?> <img src="<?php echo e(asset('loading.gif')); ?>" width="80"></button>
  </div>
</div>
<?php echo Form::close(); ?>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', ['title' => __('Setting'), 'modal' => 'lg'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\creative\resources\views/admin/setting/index.blade.php ENDPATH**/ ?>