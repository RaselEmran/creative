<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="badge-header">
            <div class="row">
                <div class="col-md-6">
                    <button class="title btn btn-outline btn-wd mt-2">
                    <i class="glyphicon fa fa-th-list"></i>
                    <?php echo e(_lang('User List')); ?>

                    </button>
                </div>
                <div class="col-md-6" style="text-align: right;">
                    <a href="<?php echo e(route('admin.user.user-manage.create')); ?>" class=" btn-icon btn btn-outline btn-round btn-wd mt-2">
                        <span class="btn-label">
                            <i class="fa fa-check"></i>
                        </span><?php echo e(_lang('Add New User')); ?></a>
                    </div>
                </div>
            </div>
            <div class="card data-tables">
                <div class="card-body table-striped table-no-bordered table-hover dataTable dtr-inline table-full-width">
                    <div class="fresh-datatables">
                        <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
                            <thead>
                                <tr>
                                    <th class="text-center"><?php echo e(_lang('SL')); ?></th>
                                    <th class="text-center"><?php echo e(_lang('Name')); ?></th>
                                    <th class="text-center"><?php echo e(_lang('Role')); ?></th>
                                    <th class="text-center"><?php echo e(_lang('Status')); ?></th>
                                    <th class="text-center"><?php echo e(_lang('Action')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center"><?php echo e($loop->index+1); ?></td>
                                    <td class="text-center"><?php echo e($user->name); ?></td>
                                    <td class="text-center"><?php echo e(getUserRoleName($user->id)); ?></td>
                                    <td class="text-center">
                                        <label class="switch">
                                            <input type="checkbox"  id="change_status" data-id="<?php echo e($user->id); ?>" data-status="<?php echo e($user->status); ?>" data-url="<?php echo e(route('admin.user.change_status',['value'=> ($user->status == 'activated' ? 'suspend' : 'activated'),'id'=>$user->id])); ?>" <?php echo e($user->status == 'activated' ? 'checked' : ''); ?>>
                                            <span class="slider"></span>
                                        </label>
                                    </td>
                                    <td class="text-center">
                                        <a href="<?php echo e(route('admin.user.user-manage.edit',$user->id)); ?>" class="btn btn-link btn-warning edit">
                                            <i class="fa fa-edit"></i>
                                        </a>
                                        <a href="" id="delete_item" data-id ="<?php echo e($user->id); ?>" data-url="<?php echo e(route('admin.user.user-manage.destroy',$user->id)); ?>" class="btn btn-link btn-danger remove">
                                            <i class="fa fa-times"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
    <?php $__env->startPush('js'); ?>
    <?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', ['title' => __('User'), 'modal' => 'lg'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\creative\resources\views/admin/user/index.blade.php ENDPATH**/ ?>