<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="badge-header">
            <div class="row">
                <div class="col-md-6">
                    <button class="title btn btn-outline btn-wd mt-2">
                    <i class="glyphicon fa fa-th-list"></i>
                    <?php echo e(_lang('Language List')); ?>

                    </button>
                </div>
                <div class="col-md-6" style="text-align: right;">
                    <a  id="content_managment" data-url="<?php echo e(route('admin.language.create')); ?>" class=" btn-icon btn btn-outline btn-round btn-wd mt-2">
                        <span class="btn-label">
                            <i class="fa fa-check"></i>
                        </span><?php echo e(_lang('Add New Language')); ?></a>
                    </div>
                </div>
            </div>
            <div class="card data-tables">
                <div class="card-body table-striped table-no-bordered table-hover dataTable dtr-inline table-full-width">
                    <div class="fresh-datatables">
                        <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
                            <thead>
                                <tr>
                                    <th class="text-center"><?php echo e(_lang('SL')); ?></th>
                                    <th class="text-center"><?php echo e(_lang('Name')); ?></th>
                                    <th class="text-center"><?php echo e(_lang('Translate')); ?></th>
                                    <th class="text-center"><?php echo e(_lang('Action')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = get_language_list(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center"><?php echo e($loop->index+1); ?></td>
                                    <td class="text-center"><?php echo e(ucwords($language)); ?></td>
                                    <td class="text-center">
                                        <a href="<?php echo e(route('admin.language.edit',$language)); ?>" class="btn btn-info"> <i class="fa fa-edit"></i><?php echo e(_lang('translate')); ?></a>
                                    </td>
                                    <td class="text-center">
                                        <a href="" id="delete_item"  data-url="<?php echo e(route('admin.language.delete',$language)); ?>" class="btn btn-link btn-danger remove">
                                            <i class="fa fa-times"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
    <?php $__env->startPush('js'); ?>
    <?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', ['title' => __('Language'), 'modal' => 'lg'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\creative\resources\views/admin/language/index.blade.php ENDPATH**/ ?>