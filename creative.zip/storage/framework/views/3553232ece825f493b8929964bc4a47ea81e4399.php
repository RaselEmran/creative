<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="badge-header">
            <div class="row">
                <div class="col-md-6">
                    <button class="title btn btn-outline btn-wd mt-2">
                    <i class="glyphicon fa fa-th-list"></i>
                    <?php echo e(_lang('Role List')); ?>

                    </button>
                </div>
                <div class="col-md-6" style="text-align: right;">
                    <a href="<?php echo e(route('admin.user.role.create')); ?>" class=" btn-icon btn btn-outline btn-round btn-wd mt-2">
                        <span class="btn-label">
                            <i class="fa fa-check"></i>
                        </span><?php echo e(_lang('Add New Roll')); ?></a>
                    </div>
                </div>
            </div>
            <div class="card data-tables">
                <div class="card-body table-striped table-no-bordered table-hover dataTable dtr-inline table-full-width">
                    <div class="fresh-datatables">
                        <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
                            <thead>
                                <tr>
                                    <th class="text-center" style="width: 20%"><?php echo e(_lang('SL')); ?></th>
                                    <th class="text-center" style="width: 50%"><?php echo e(_lang('Role')); ?></th>
                                    <th class="text-center"><?php echo e(_lang('Action')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center"><?php echo e($loop->index+1); ?></td>
                                    <td class="text-center"><?php echo e($role->name); ?></td>
                                    <td class="text-center">
                                        <a href="<?php echo e(route('admin.user.role.edit',$role->id)); ?>" class="btn btn-link btn-warning edit"><i class="fa fa-edit"></i></a>
                                        <a href="" id="delete_item" data-id ="<?php echo e($role->id); ?>" data-url="<?php echo e(route('admin.user.role.destroy',$role->id)); ?>" class="btn btn-link btn-danger remove"><i class="fa fa-times"></i></a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', ['title' => __('Role'), 'modal' => 'lg'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\creative\resources\views/admin/acl/index.blade.php ENDPATH**/ ?>