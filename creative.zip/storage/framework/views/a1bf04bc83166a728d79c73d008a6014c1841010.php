<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="badge-header">
            <div class="row">
                <div class="col-md-6">
                    <button class="title btn btn-outline btn-wd mt-2">
                    <i class="fa fa-check"></i>
                    
                    <?php echo e(_lang('Role Create')); ?>

                    </button>
                </div>
                <div class="col-md-6" style="text-align: right;">
                    <a href="<?php echo e(route('admin.user.role.index')); ?>" class=" btn-icon btn btn-outline btn-round btn-wd mt-2">
                        <span class="btn-label">
                            <i class="glyphicon fa fa-th-list"></i>
                        </span><?php echo e(_lang('Role List')); ?>

                    </a>
                </div>
            </div>
        </div>
        
        <?php echo Form::open(['route' => 'admin.user.role.store', 'id'=>'content_form','files' => true, 'method' => 'POST']); ?>

        <div class="card table-with-links">
            <div class="card-body">
                <div class="row mb-2">
                    <?php echo e(Form::label('name', _lang('Role Name'),['class'=>'col-sm-2 col-form-label mx-2'])); ?>

                    <div class="col-sm-8">
                        <?php echo e(Form::text('name', null, ['class' => 'form-control', 'placeholder' => _lang('Role Name'),'required'=>''])); ?>

                    </div>
                    
                </div>
            </div>
        </div>
        <h6 class="badge badge-success"><?php echo e(_lang('permission')); ?></h6>
        <div class="tbg">
            <table class="table table-bordered">
                <?php $__currentLoopData = split_name($permissions); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td rowspan ="<?php echo e(count($element)+1); ?>"><?php echo $key; ?></td>
                    <td rowspan="<?php echo e(count($element)+1); ?>">
                        <div class="form-check">
                            <label class="form-check-label">
                                <input class="form-check-input select_all" type="checkbox" id="select_all_<?php echo e($key); ?>" data-id="<?php echo e($key); ?>">
                                <span class="form-check-sign elect_all_<?php echo e($key); ?>"></span>
                                <?php echo e(_lang('Select All')); ?>

                            </label>
                        </div>
                    </td>
                </tr>
                <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <div class="form-check">
                            <label class="form-check-label">
                                <input class="form-check-input <?php echo e($key); ?>" type="checkbox" id="<?php echo e($per); ?>" multiple="multiple" name="permissions[]" value="<?php echo e($per); ?>">
                                <span class="form-check-sign"></span>
                                <?php echo e(tospane($per)); ?>

                            </label>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
        <div class="row">
            <div class="col-md-6 mx-auto text-center">
                
                <?php echo e(Form::submit(_lang('Set Permission'), ['class' => 'btn btn-outline btn-success btn-round btn-wd w-100 ', 'id' => 'submit'])); ?>

                <button type="button" class="btn btn-link" id="submiting" style="display: none;" disabled=""><?php echo e(_lang('Submiting')); ?> <img src="<?php echo e(asset('loading.gif')); ?>" width="50"></button>
            </div>
        </div>
        <?php echo Form::close(); ?>

        
        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script>
$(document).on('click','.select_all',function(){
var id =$(this).data('id');
if (this.checked) {
$("."+id).prop('checked', true);
} else{
$("."+id).prop('checked', false);
}
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', ['title' => __('Role'), 'modal' => 'lg'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\creative\resources\views/admin/acl/create.blade.php ENDPATH**/ ?>