<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="badge-header">
            <div class="row">
                <div class="col-md-6">
                    <button class="title btn btn-outline btn-wd mt-2">
                    <i class="glyphicon fa fa-th-list"></i>
                    <?php echo e(_lang('Customer List')); ?>

                    </button>
                </div>
                <div class="col-md-6" style="text-align: right;">
                    <a id="content_managment" data-url="<?php echo e(route('admin.customer.create')); ?>" class=" btn-icon btn btn-outline btn-round btn-wd mt-2">
                        <span class="btn-label">
                            <i class="fa fa-check"></i>
                        </span><?php echo e(_lang('Add New Customer')); ?></a>
                    </div>
                </div>
            </div>
            <div class="card data-tables">
                <div class="card-body table-striped table-no-bordered table-hover dataTable dtr-inline table-full-width">
                    <div class="fresh-datatables">
                        <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
                            <thead>
                                <tr>
                                    <th class="text-center"><?php echo e(_lang('SL')); ?></th>
                                    <th class="text-center"><?php echo e(_lang('Name')); ?></th>
                                    <th class="text-center"><?php echo e(_lang('Email')); ?></th>
                                    <th class="text-center"><?php echo e(_lang('Phone')); ?></th>
                                    <th class="text-center"><?php echo e(_lang('Action')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center"><?php echo e($loop->index+1); ?></td>
                                    <td class="text-center"><?php echo e($model->name); ?></td>
                                    <td class="text-center"><?php echo e($model->email); ?></td>
                                    <td class="text-center"><?php echo e($model->phone); ?></td>
                                    <td class="text-center">
                                        <a id="content_managment" data-url="<?php echo e(route('admin.customer.edit',$model->id)); ?>" class="btn btn-link btn-warning edit">
                                            <i class="fa fa-edit"></i>
                                        </a>
                                        <a href="" id="delete_item" data-id ="<?php echo e($model->id); ?>" data-url="<?php echo e(route('admin.customer.destroy',$model->id)); ?>" class="btn btn-link btn-danger remove">
                                            <i class="fa fa-times"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
    <?php $__env->startPush('js'); ?>
    <?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', ['title' => __('Customer'), 'modal' => 'lg'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\creative\resources\views/admin/customer/index.blade.php ENDPATH**/ ?>